import os
import sys
import shutil
import argparse
import numpy as np
from tqdm import tqdm

np.random.seed(10)

IMAGE_SUFFIX = ('.jpg', '.JPG', 'png', 'PNG')
GT_SUFFIX = '.xml'


def parse_arguments(argv):
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_path', type=str, help='Directory where dataset are located.', default='')
    parser.add_argument('--save_path', type=str, help='Directory where images and gt files are saved.', default='')
    parser.add_argument('--num_valid', type=int, help='Number of valid images', default=0)
    parser.add_argument('--num_test', type=int, help='Number of test images', default=0)
    return parser.parse_args(argv)


def make_multi_dirs(*args):
    for arg in args:
        os.makedirs(arg, exist_ok=True)


def copy_image(index, image_list, gt_list, save_path):
    for idx in tqdm(index):
        image_file = image_list[idx]
        gt_file = gt_list[idx]
        shutil.copy(image_file, save_path)
        shutil.copy(gt_file, save_path)


def main(args):
    data_path = args.data_path
    save_path = args.save_path
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    train_path = os.path.join(save_path, 'train')
    valid_path = os.path.join(save_path, 'valid')
    test_path = os.path.join(save_path, 'test')
    num_valid = args.num_valid
    num_test = args.num_test

    make_multi_dirs(train_path, valid_path, test_path)

    image_files_list = []
    gt_files_list = []
    for file in os.listdir(data_path):
        if file.endswith(IMAGE_SUFFIX):
            image_files_list.append(os.path.join(data_path, file))
        elif file.endswith(GT_SUFFIX):
            gt_files_list.append(os.path.join(data_path, file))

    image_files_list = sorted(image_files_list)
    gt_files_list = sorted(gt_files_list)
    assert len(image_files_list) == len(gt_files_list), \
        'The number of image files does not equal to that of gt files in data path!'
    num_files = len(image_files_list)

    test_index = list(np.random.choice(range(num_files), size=int(num_test), replace=False))
    valid_train_index = [x for x in range(num_files) if x not in test_index]
    if num_valid:
        valid_index = list(np.random.choice(valid_train_index, size=int(num_valid), replace=False))
    else:
        valid_index = []
    train_index = [x for x in valid_train_index if x not in valid_index]

    print('Total:%d' % num_files)
    print('Train:%d' % len(train_index))
    copy_image(train_index, image_files_list, gt_files_list, train_path)
    if num_valid > 0:
        print('Valid:%d' % len(valid_index))
        copy_image(valid_index, image_files_list, gt_files_list, valid_path)
    if num_test > 0:
        print('Test:%d' % len(test_index))
        copy_image(test_index, image_files_list, gt_files_list, test_path)


if __name__ == '__main__':
    main(args=parse_arguments(sys.argv[1:]))
