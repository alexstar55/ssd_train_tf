import os
import sys
import shutil
import argparse
import numpy as np
from tqdm import tqdm

np.random.seed(10)

IMAGE_SUFFIX = ('.jpg', '.JPG')


def parse_arguments(argv):
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_path', type=str, help='Datasets directroy', default='')
    parser.add_argument('--save_path', type=str, help='Save directory', default='')
    parser.add_argument('--test_ratio', type=float, help='Ratio of test images', default=0.1)
    parser.add_argument('--flag', type=str, help='xml or json', default='xml')
    return parser.parse_args(argv)


def make_multi_dirs(*args):
    for arg in args:
        os.makedirs(arg, exist_ok=True)


def copy_image(index, image_list, gt_list, save_path):
    for idx in tqdm(index):
        image_file = image_list[idx]
        gt_file = gt_list[idx]
        shutil.copy(image_file, save_path)
        shutil.copy(gt_file, save_path)


def write_txt(index, image_list, save_path, txt_name):
    with open(os.path.join(save_path, txt_name), 'w') as file:
        for idx in tqdm(index):
            image_file = image_list[idx]
            file.write(os.path.basename(image_file))
            file.write('\n')


def get_camera_info(json_list):
    camera_id_info = {}
    for file_path in json_list:
        file_name = os.path.basename(file_path)
        camera_id = str(file_name.split('_')[0])
        if len(file_name.split('_')) > 2:
            camera_id += '_' + str(file_name.split('_')[1])
        if camera_id not in camera_id_info.keys():
            camera_id_info[camera_id] = 0
        camera_id_info[camera_id] += 1
    return camera_id_info


def main(args):
    data_path = args.data_path
    save_path = args.save_path
    os.makedirs(save_path, exist_ok=True)
    test_path = os.path.join(save_path, 'test')
    test_ratio = args.test_ratio
    os.makedirs(test_path, exist_ok=True)
    gt_suffix = '.' + args.flag

    image_files_list = []
    gt_files_list = []
    for file in os.listdir(data_path):
        if file.endswith(IMAGE_SUFFIX):
            image_files_list.append(os.path.join(data_path, file))
        elif file.endswith(gt_suffix):
            gt_files_list.append(os.path.join(data_path, file))

    image_files_list = sorted(image_files_list)
    gt_files_list = sorted(gt_files_list)
    assert len(image_files_list) == len(gt_files_list), \
        'The number of image files does not equal to that of gt files in data path!'
    num_files = len(image_files_list)

    camera_id_info = get_camera_info(gt_files_list)

    test_index = []
    if test_ratio:
        init_ind = 0
        for key, value in camera_id_info.items():
            if value <= 1:
                continue
            choice_size = int(value * test_ratio)
            if choice_size < 1:
                choice_size = 1
            temp_test_index = list(np.random.choice(range(init_ind, init_ind + value), size=choice_size, replace=False))
            init_ind += value
            test_index.extend(temp_test_index)
    train_index = [x for x in range(num_files) if x not in test_index]

    print('Total:%d' % num_files)
    print('Train:%d' % len(train_index))
    write_txt(train_index, image_files_list, save_path, 'trainval.txt')
    print('Test:%d' % len(test_index))
    write_txt(test_index, image_files_list, save_path, 'test.txt')
    copy_image(test_index, image_files_list, gt_files_list, test_path)

    print('Process finished!')


if __name__ == '__main__':
    main(args=parse_arguments(sys.argv[1:]))
