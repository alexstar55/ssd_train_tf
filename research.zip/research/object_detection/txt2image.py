import os
import glob
from PIL import Image, ImageDraw, ImageFont


txt_path = 'C:\\Users\\10156101\\Downloads\\label_pred.txt'
test_image_path = 'E:\\Datasets\\定番\\label\\test'
output_path = 'C:\\Users\\10156101\\Desktop\\result'
if not os.path.exists(output_path):
    os.makedirs(output_path)

txt_file = open(txt_path, 'r')
file_list = txt_file.readlines()
split_file_list = [x.strip().split(' ') for x in file_list]
image_names = [x[0] for x in split_file_list]
confidence = [float(x[-1]) for x in split_file_list]
BB = [tuple(float(z) for z in x[1:5]) for x in split_file_list]
image_list = glob.glob(os.path.join(test_image_path, '*.jpg'))
image_list = sorted(image_list)


current_name = ''
image_info_dict = {}
for i in range(len(image_names)):
    if image_names[i] != current_name:
        current_name = image_names[i]
        image_info_dict[image_names[i]] = {}
        image_info_dict[image_names[i]]['boxes'] = []
        image_info_dict[image_names[i]]['classnames'] = []
        image_info_dict[image_names[i]]['scores'] = []

    image_info_dict[image_names[i]]['boxes'].append(BB[i])
    image_info_dict[image_names[i]]['classnames'].append('label')
    image_info_dict[image_names[i]]['scores'].append(confidence[i])

for file in image_list:
    image = Image.open(file)
    image_name = os.path.basename(file)
    if image_name in image_info_dict.keys():
        boxes = image_info_dict[image_name]['boxes']
        classnames = image_info_dict[image_name]['classnames']
        scores = image_info_dict[image_name]['scores']
        draw = ImageDraw.Draw(image)
        for ind, point in enumerate(boxes):
            xmin, ymin, xmax, ymax = point
            draw.line([(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax), (xmin, ymin)], 'chartreuse', width=3)
            draw.rectangle([(xmin, ymin - 10), (xmin + 50, ymin)], fill='chartreuse')
            draw.text((xmin, ymin - 10), '%s:%.2f' % (classnames[ind], scores[ind]), fill='black',
                      font=ImageFont.truetype('calibri.ttf', 12))
    image.save(os.path.join(output_path, image_name))
    print('Drawing: %s' % image_name)

print('Finished!')
