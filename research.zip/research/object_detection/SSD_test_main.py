import os
import sys
import argparse
from object_detection.SSD_Detector_test import Detector


def parse_arguments(argv):
    parser = argparse.ArgumentParser()

    parser.add_argument('--draw_box', type=int, help='Choose whether draw bounding boxes on test image or not.')
    parser.add_argument('--write_xml', type=int, help='Choose whether write test result into xml files or not.')
    parser.add_argument('--model_path', type=str, help='Directory where models are located.')
    parser.add_argument('--output_path', type=str, help='Directory to save result')
    parser.add_argument('--test_image_path', type=str, help='Directory where test samples are located.')

    return parser.parse_args(argv)


if __name__ == '__main__':
    args = parse_arguments(sys.argv[1:])
    model_path = args.model_path
    output_path = args.output_path
    test_image_path = args.test_image_path
    pbtxt_path = os.path.join(model_path, 'SSD.pbtxt')

    score_threshold = 0.5
    nms = 0.3
    resize = 0.5

    detector = Detector(output_path, model_path, pbtxt_path)

    if args.draw_box == 1 and args.write_xml == 0:
        detector.draw_bboxes(test_image_path, score_threshold, nms, resize)
    elif args.draw_box == 0 and args.write_xml == 1:
        detector.write_xml(test_image_path, score_threshold, nms, resize)
    elif args.draw_box == 1 and args.write_xml == 1:
        detector.draw_and_write(test_image_path, score_threshold, nms, resize)
    elif args.draw_box == 0 and args.write_xml == 0:
        raise ValueError('At least one of the parameters draw_box and write_xml must equal to 1')
    else:
        raise ValueError('The value of parameters draw_box and write_xml must be 0 or 1')
