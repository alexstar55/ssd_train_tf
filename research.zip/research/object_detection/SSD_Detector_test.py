import os
import time
import lxml.builder
import lxml.etree
import numpy as np
import tensorflow as tf
import cv2
from PIL import Image
from tqdm import tqdm
from object_detection.utils import label_map_util
from object_detection.utils import visualization_utils as vis_util


# os.environ["CUDA_VISIBLE_DEVICES"] = "2"


class ImageInfo:
    """Class for saving information and detection results of each test image.

    Attributes:
        image_name: Name of each test image.
        image_path: Path of each test image.
        image_size: Size of each test image.
        detect_results: Detection results of each test image.
        draw_bboxes_path: Where the result images are saving.
        write_xml_path: Where the xml files of detection results are saving.
    """

    def __init__(self, image_name, image_path, image_size, detect_results,
                 draw_bboxes_path, write_xml_path,
                 inference_time):
        self.image_name = image_name
        self.image_path = image_path
        self.image_size = image_size
        self.detect_results = detect_results
        self.draw_bboxes_path = draw_bboxes_path
        self.write_xml_path = write_xml_path
        self.inference_time = inference_time


class Detector:
    """Class for running SSD detection.

    Attributes:
        detection_graph: A graph for SSD model.
        sess: Create a driver for graph execution.
        tensor_dict:A dictionary for saving tensor of detection results
        image_tensor: A tensor for feeding image data
        category_index: A dictionary for saving category and index.
        output_path: Directory where all files of SSD are placed.
        model_path: Version of SSD model.
        model_path: Directory where SSD model is placed.
    """

    def __init__(self, output_path, model_path, pbtxt_path):
        config = tf.ConfigProto()
        config.gpu_options.allow_growth = True
        self.detection_graph = tf.Graph()
        self.sess = tf.Session(graph=self.detection_graph, config=config)
        self.tensor_dict = {}
        self.image_tensor = None
        self.category_index = {}
        self.output_path = output_path
        if not os.path.exists(self.output_path):
            os.makedirs(self.output_path)
        self.model_path = os.path.join(model_path, 'frozen_inference_graph.pb')

        self.detection_graph_init(self.model_path)
        self.load_category(pbtxt_path)

    def detection_graph_init(self, model_path):
        """Initialization of graph and SSD model.
        """
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.allow_growth = True
        with self.detection_graph.as_default():
            od_graph_def = tf.GraphDef()
            with tf.gfile.GFile(model_path, 'rb') as fid:
                serialized_graph = fid.read()
                od_graph_def.ParseFromString(serialized_graph)
                tf.import_graph_def(od_graph_def, name='')
                ops = tf.get_default_graph().get_operations()
                all_tensor_names = {output.name for op in ops for output in
                                    op.outputs}
                self.tensor_dict = {}
                for key in ['num_detections',
                            'detection_boxes',
                            'detection_scores',
                            'detection_classes',
                            'detection_masks']:
                    tensor_name = key + ':0'
                    if tensor_name in all_tensor_names:
                        self.tensor_dict[key] = tf.get_default_graph(). \
                            get_tensor_by_name(tensor_name)
                self.image_tensor = tf.get_default_graph(). \
                    get_tensor_by_name('image_tensor:0')

    def load_category(self, pbtxt_path):
        """Load category and index from pbtxt.
        """
        self.category_index = label_map_util. \
            create_category_index_from_labelmap(pbtxt_path,
                                                use_display_name=True)

    def inference(self,
                  image_list,
                  score_threshold,
                  nms,
                  resize,
                  test_result_path):
        """Run SSD model and save the detection results into a list.
        """
        image_info_list = []
        with self.detection_graph.as_default():
            for image_path in tqdm(image_list, desc='Inference'):
                filename = os.path.basename(image_path)
                image = Image.open(image_path)
                image_shape = image.size
                image_np = load_image_into_numpy_array(image, resize)
                start_time = time.time()
                result_dict = self.sess.run(self.tensor_dict,
                                            feed_dict={self.image_tensor: np.expand_dims(image_np, 0)})
                end_time = time.time()
                inference_time = end_time - start_time
                save_path_jpg = os.path.join(test_result_path, 'image',
                                             str(filename.split('.')[0]) + '.jpg')
                                             # + '_%.2f_%.2f.jpg'
                                             # % (score_threshold,
                                             #    nms))
                save_path_xml = os.path.join(test_result_path, 'xml',
                                             str(filename.split('.')[0])
                                             + '.xml')

                image_info = ImageInfo(filename, image_path, image_shape,
                                       result_dict, save_path_jpg,
                                       save_path_xml, inference_time)
                image_info_list.append(image_info)

        return image_info_list

    def draw_bboxes(self, test_image_path, score_threshold, nms, resize):
        """Drawing bounding boxes on test image.
        """
        image_list = load_image_files(test_image_path)

        test_result_path = os.path.join(self.output_path, 'test_result_%.2f_%.2f' % (score_threshold, nms))
        if not os.path.exists(test_result_path):
            os.mkdir(test_result_path)
            os.mkdir(os.path.join(test_result_path, 'image'))
            os.mkdir(os.path.join(test_result_path, 'xml'))

        image_info_list = self.inference(image_list, score_threshold, nms,
                                         resize, test_result_path)

        draw_result_on_image(image_info_list, score_threshold, nms,
                             self.category_index)

    def write_xml(self, test_image_path, score_threshold, nms, resize):
        """Writing detection results into xml files.
        """
        image_list = load_image_files(test_image_path)

        test_result_path = os.path.join(self.output_path, 'test_result_%.2f_%.2f' % (score_threshold, nms))
        if not os.path.exists(test_result_path):
            os.mkdir(test_result_path)
            os.mkdir(os.path.join(test_result_path, 'image'))
            os.mkdir(os.path.join(test_result_path, 'xml'))

        image_info_list = self.inference(image_list, score_threshold, nms,
                                         resize, test_result_path)

        write_result_into_xml(test_result_path, image_info_list,
                              score_threshold, nms, self.category_index)

    def draw_and_write(self, test_image_path, score_threshold, nms, resize):
        """Running both drawing bounding boxes and writing xml.
        """
        image_list = load_image_files(test_image_path)

        test_result_path = os.path.join(self.output_path, 'test_result_%.2f_%.2f' % (score_threshold, nms))
        if not os.path.exists(test_result_path):
            os.mkdir(test_result_path)
            os.mkdir(os.path.join(test_result_path, 'image'))
            os.mkdir(os.path.join(test_result_path, 'xml'))

        image_info_list = self.inference(image_list, score_threshold, nms,
                                         resize, test_result_path)

        draw_result_on_image(image_info_list, score_threshold, nms,
                             self.category_index)

        write_result_into_xml(test_result_path, image_info_list,
                              score_threshold, nms, self.category_index)


def bboxes_nms(classes, scores, bboxes, nms_threshold=0.45):
    """Apply non-maximum selection to bounding boxes.
    """
    keep_bboxes = np.ones(scores.shape, dtype=np.bool)
    for i in range(scores.size - 1):
        if keep_bboxes[i] > 0:
            # Computer overlap with bboxes which are following.
            overlap = bboxes_jaccard(bboxes[i], bboxes[(i + 1):])
            keep_overlap = np.less(overlap, nms_threshold)
            keep_bboxes[(i + 1):] = np.logical_and(keep_bboxes[(i + 1):],
                                                   keep_overlap)

    idxes = np.where(keep_bboxes)
    return classes[idxes], scores[idxes], bboxes[idxes]


def bboxes_jaccard(bboxes1, bboxes2):
    """Computing jaccard index between bboxes1 and bboxes2.
    """
    bboxes1 = np.transpose(bboxes1)
    bboxes2 = np.transpose(bboxes2)
    # Intersection bbox and volume.
    int_ymin = np.maximum(bboxes1[0], bboxes2[0])
    int_xmin = np.maximum(bboxes1[1], bboxes2[1])
    int_ymax = np.minimum(bboxes1[2], bboxes2[2])
    int_xmax = np.minimum(bboxes1[3], bboxes2[3])

    int_h = np.maximum(int_ymax - int_ymin, 0.)
    int_w = np.maximum(int_xmax - int_xmin, 0.)
    int_vol = int_h * int_w
    # Union volume.
    vol1 = (bboxes1[2] - bboxes1[0]) * (bboxes1[3] - bboxes1[1])
    vol2 = (bboxes2[2] - bboxes2[0]) * (bboxes2[3] - bboxes2[1])
    jaccard = int_vol / (vol1 + vol2 - int_vol)
    return jaccard


def load_image_into_numpy_array(image, resize):
    """Convert image data to ndarray type
    """
    im_width, im_height = image.size
    if resize is not None:
        image = image.resize((int(im_width * resize), int(im_height * resize)))

    im_width, im_height = image.size
    return np.array(image.getdata()).reshape((im_height, im_width,
                                              3)).astype(np.uint8)


def savexml(imgshape, imgpath, boxes, classnames, save_path):
    """Save result of model output as .xml file
    """
    maker = lxml.builder.ElementMaker()
    xml = maker.annotation(
        maker.folder(os.path.dirname(imgpath)),
        maker.filename(os.path.basename(imgpath)),
        maker.path(imgpath),
        maker.source(maker.database('Unknown')),
        maker.size(maker.width(str(imgshape[0])),
                   maker.height(str(imgshape[1])),
                   maker.depth('3'), ),
        maker.segmented('0'),
    )

    for i in range(len(boxes)):
        class_name = classnames[i]

        xmin = int(boxes[i][1] * imgshape[0])
        ymin = int(boxes[i][0] * imgshape[1])
        xmax = int(boxes[i][3] * imgshape[0])
        ymax = int(boxes[i][2] * imgshape[1])

        xml.append(maker.object(maker.name(class_name),
                                maker.pose('Unspecified'),
                                maker.truncated('0'),
                                maker.difficult('0'),
                                maker.shapetype('rectangle'),
                                maker.bndbox(maker.xmin(str(xmin)),
                                             maker.ymin(str(ymin)),
                                             maker.xmax(str(xmax)),
                                             maker.ymax(str(ymax))
                                             )
                                )
                   )

    with open(save_path, 'wb') as f:
        f.write(lxml.etree.tostring(xml, pretty_print=True))


def save_txt(filename, file_dict, boxes, classnames, scores,
             image_shape):
    """Save result of model output as .txt file for calculating mAP
    """

    for i in range(len(classnames)):
        classname = classnames[i]
        xmin = int(boxes[i][1] * image_shape[0])
        ymin = int(boxes[i][0] * image_shape[1])
        xmax = int(boxes[i][3] * image_shape[0])
        ymax = int(boxes[i][2] * image_shape[1])

        score = scores[i]

        text = '%s %f %d %d %d %d' % (filename, score, xmin, ymin, xmax, ymax)

        file_to_write = file_dict[classname]

        file_to_write.write(text)
        file_to_write.write('\n')


def load_image_files(image_path, suffix=None):
    """Load image file names into list
    """
    image_list = []
    for i in os.listdir(image_path):
        if suffix is not None:
            if os.path.splitext(i)[1] == '.' + str(suffix):
                path = os.path.join(image_path, i)
                image_list.append(path)
        else:
            if os.path.splitext(i)[1] in ['.jpg', '.JPG', '.png', 'PNG']:
                path = os.path.join(image_path, i)
                image_list.append(path)

    return image_list


def threshold_for_result(boxes, scores, classes, category_index,
                         max_boxes_to_draw=20, min_score_thresh=.5):
    """Filtering boxes according to confidence threshold
    """
    boxes_list = []
    class_names = []
    score_list = []
    for i in range(min(max_boxes_to_draw, boxes.shape[0])):
        if scores[i] > min_score_thresh:
            box = tuple(boxes[i].tolist())
            boxes_list.append(box)
            score_list.append(scores[i])
            if classes[i] in category_index.keys():
                class_name = category_index[classes[i]]['name']
                class_names.append(class_name)

    return boxes_list, class_names, score_list


def result_post_process(result_dict, nms, score_threshold, category_index):
    """Post-processing of detection results.
    """
    rclasses = result_dict['detection_classes'][0].astype(np.uint8)
    rbboxes = result_dict['detection_boxes'][0]
    rscores = result_dict['detection_scores'][0]
    if nms:
        rclasses, rscores, rbboxes = bboxes_nms(rclasses, rscores, rbboxes,
                                                nms_threshold=nms)
    boxes, classnames, scores = threshold_for_result(rbboxes, rscores,
                                                     rclasses,
                                                     category_index,
                                                     min_score_thresh=score_threshold)
    return boxes, classnames, scores


def draw_result_on_image(image_info_list, score_threshold, nms,
                         category_index):
    """Function of drawing bounding boxes on each test image.
    """
    for i in range(len(image_info_list)):
        image_info = image_info_list[i]
        image = Image.open(image_info.image_path)
        image_np = load_image_into_numpy_array(image, 0.5)
        result_dict = image_info.detect_results
        save_path_jpg = image_info.draw_bboxes_path
        inference_time = image_info.inference_time
        boxes, classnames, scores = result_post_process(result_dict, nms,
                                                        score_threshold,
                                                        category_index)
        vis_util.visualize_demo1(image_np, boxes, classnames, scores,
                                 instance_masks=result_dict.get
                                 ('detection_masks'),
                                 use_normalized_coordinates=True,
                                 line_thickness=2)

        image_np = cv2.cvtColor(image_np, cv2.COLOR_BGR2RGB)
        image_np = cv2.resize(image_np, (1200, 900))
        cv2.imwrite(save_path_jpg, image_np)
        print('Drawing: %d %s %.4f s' % (i, os.path.basename(save_path_jpg),
                                         inference_time))


def write_result_into_xml(test_result_path, image_info_list,
                          score_threshold, nms, category_index):
    """Function of writing detection results into xml files.
    """
    file_dict = {}
    for class_dict in category_index.values():
        class_names = class_dict['name']
        file = open(os.path.join(test_result_path, '%s_pred.txt' % class_names), 'a')
        file_dict[class_names] = file

    for i in range(len(image_info_list)):
        image_info = image_info_list[i]
        filename = image_info.image_name
        image_shape = image_info.image_size
        result_dict = image_info.detect_results
        save_path_xml = image_info.write_xml_path
        inference_time = image_info.inference_time
        boxes, classnames, scores = result_post_process(result_dict, nms,
                                                        score_threshold,
                                                        category_index)
        savexml(image_shape, filename, boxes, classnames, save_path_xml)
        save_txt(filename, file_dict, boxes, classnames, scores, image_shape)
        print('Writing: %d %s %.4f s' % (i, os.path.basename(save_path_xml),
                                         inference_time))

    for file in file_dict.values():
        file.close()
