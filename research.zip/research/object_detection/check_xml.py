import os
import sys
import glob
import argparse
import xml.etree.ElementTree as Et
from object_detection import LogUtil


def parse_arguments(argv):
    parser = argparse.ArgumentParser()
    parser.add_argument('--xml_path', type=str, help='', default=r'')
    return parser.parse_args(argv)


if __name__ == '__main__':
    logging = LogUtil.CreateLog(os.getcwd(), 'xml_log')
    logger = logging.create_log()

    args = parse_arguments(sys.argv[1:])
    xml_path = args.xml_path
    num = 0
    for xml_file in glob.glob(xml_path + '/*.xml'):
        tree = Et.parse(xml_file)
        root = tree.getroot()
        xml_file_name = os.path.basename(xml_file)
        xml_file_dir = os.path.dirname(xml_file)
        image_name_list = [str(xml_file_name.split('.')[0]) + '.jpg', str(xml_file_name.split('.')[0]) + '.JPG']
        file_name = root.find('filename').text
        num += 1
        if file_name not in image_name_list:
            logger.error('Image file name in %s is different from name of xml!' % xml_file_name)
            error_solve = False
            for name in image_name_list:
                if os.path.isfile(os.path.join(xml_file_dir, name)):
                    root.find('filename').text = name
                    root.find('path').text = os.path.join(xml_file_dir, name)
                    tree.write(xml_file)
                    logger.info('Change image file name in %s to %s' % (xml_file_name, name))
                    error_solve = True
                    break
            if not error_solve:
                logger.error('No image file has same name with %s. Please check!' % xml_file_name)
        else:
            if not os.path.isfile(os.path.join(xml_file_dir, file_name)):
                logger.error('No image file has same name with %s. Please check!' % xml_file_name)
        print(num)
    logger.info('Total %d xml files are checked!' % num)
