import os
import glob
import numpy as np
import sys
import argparse
import xml.etree.ElementTree as ET


def parse_arguments(argv):
    parser = argparse.ArgumentParser()
    parser.add_argument('--category_list', type=str, help='Category list')
    parser.add_argument('--test_result_path', type=str, help='Directory where test results are located.')
    parser.add_argument('--test_image_path', type=str, help='Directory where test samples are located.')

    return parser.parse_args(argv)


def parse_rec(filename):
    """Reading gt files.
    """
    tree = ET.parse(filename)
    objects = []
    for obj in tree.findall('object'):
        obj_struct = {}
        obj_struct['name'] = obj.find('name').text
        obj_struct['pose'] = obj.find('pose').text
        obj_struct['truncated'] = int(obj.find('truncated').text)
        obj_struct['difficult'] = int(obj.find('difficult').text)
        bbox = obj.find('bndbox')
        obj_struct['bbox'] = [int(bbox.find('xmin').text),
                              int(bbox.find('ymin').text),
                              int(bbox.find('xmax').text),
                              int(bbox.find('ymax').text)]
        objects.append(obj_struct)

    return objects


def voc_ap(rec, prec, use_07_metric=False):
    """ Calculating AP according to recall and precision
    """
    if use_07_metric:
        # 11 point metric
        ap = 0.
        for t in np.arange(0., 1.1, 0.1):
            if np.sum(rec >= t) == 0:
                p = 0
            else:
                p = np.max(prec[rec >= t])
            ap = ap + p / 11.
    else:
        # correct AP calculation
        # first append sentinel values at the end
        mrec = np.concatenate(([0.], rec, [1.]))
        mpre = np.concatenate(([0.], prec, [0.]))

        # compute the precision envelope
        for i in range(mpre.size - 1, 0, -1):
            mpre[i - 1] = np.maximum(mpre[i - 1], mpre[i])

        # to calculate area under PR curve, look for points
        # where X axis (recall) changes value
        i = np.where(mrec[1:] != mrec[:-1])[0]

        # and sum (\Delta recall) * prec
        ap = np.sum((mrec[i + 1] - mrec[i]) * mpre[i + 1])
    return ap


def mAP_eval(gt_path, test_result_path, classname, ovthresh=0.5):
    """Calculating recall and precision
    """
    recs = {}
    image_name_list = []
    for xml_file in glob.glob(gt_path + '/*.xml'):
        image_name = os.path.basename(xml_file).split('.')[0]
        recs[image_name] = parse_rec(xml_file)
        image_name_list.append(image_name)

    class_recs = {}
    npos = 0
    for imagename in image_name_list:
        R = [obj for obj in recs[imagename] if obj['name'] == classname]
        bbox = np.array([x['bbox'] for x in R])
        difficult = np.array([x['difficult'] for x in R]).astype(np.bool)
        det = [False] * len(R)
        npos = npos + sum(~difficult)
        class_recs[imagename] = {'bbox': bbox,
                                 'difficult': difficult,
                                 'det': det}

    prediction_txt_file = os.path.join(test_result_path, '%s_pred.txt' % classname)
    with open(prediction_txt_file, 'r') as f:
        lines = f.readlines()

    if npos == 0 or not lines:
        return 0.0, 0.0, 0.0

    splitlines = [x.strip().split(' ') for x in lines]
    image_ids = [x[0].split('.')[0] for x in splitlines]
    confidence = np.array([float(x[1]) for x in splitlines])
    BB = np.array([[float(z) for z in x[2:]] for x in splitlines])

    nd = len(image_ids)
    tp = np.zeros(nd)
    fp = np.zeros(nd)

    if BB.shape[0] > 0:
        # sort by confidence
        sorted_ind = np.argsort(-confidence)
        sorted_scores = np.sort(-confidence)
        BB = BB[sorted_ind, :]
        image_ids = [image_ids[x] for x in sorted_ind]

        for d in range(nd):
            R = class_recs[image_ids[d]]
            bb = BB[d, :].astype(float)
            ovmax = -np.inf
            BBGT = R['bbox'].astype(float)

            if BBGT.size > 0:
                # compute overlaps
                # intersection
                ixmin = np.maximum(BBGT[:, 0], bb[0])
                iymin = np.maximum(BBGT[:, 1], bb[1])
                ixmax = np.minimum(BBGT[:, 2], bb[2])
                iymax = np.minimum(BBGT[:, 3], bb[3])
                iw = np.maximum(ixmax - ixmin + 1., 0.)
                ih = np.maximum(iymax - iymin + 1., 0.)
                inters = iw * ih

                # union
                uni = ((bb[2] - bb[0] + 1.) * (bb[3] - bb[1] + 1.) +
                       (BBGT[:, 2] - BBGT[:, 0] + 1.) *
                       (BBGT[:, 3] - BBGT[:, 1] + 1.) - inters)

                overlaps = inters / uni
                ovmax = np.max(overlaps)
                jmax = np.argmax(overlaps)

            if ovmax > ovthresh:
                if not R['difficult'][jmax]:
                    if not R['det'][jmax]:
                        tp[d] = 1.
                        R['det'][jmax] = 1
                    else:
                        fp[d] = 1.
            else:
                fp[d] = 1.
        # compute precision recall
        fp = np.cumsum(fp)
        tp = np.cumsum(tp)
        rec = tp / float(npos)
        # avoid divide by zero in case the first detection matches a difficult
        # ground truth
        prec = tp / np.maximum(tp + fp, np.finfo(np.float64).eps)

        recall = rec[-1]
        precision = prec[-1]
        ap = voc_ap(rec, prec)

    return recall, precision, ap


def ap_of_every_class(test_result_path, classes, test_image_path):
    """Calculating AP of each class and mAP"""
    file_txt = open(os.path.join(test_result_path, 'mAP.txt'), 'a')

    aps = []
    for i, cls in enumerate(classes):
        rec, prec, ap = mAP_eval(test_image_path, test_result_path, cls)
        aps += [ap]
        log_ap = '%s: recall=%.4f precision=%.4f AP=%.4f' % (cls, rec, prec, ap)
        print(log_ap)
        file_txt.write(log_ap)
        file_txt.write('\n')

    log_map = 'mAP=%.4f' % np.mean(aps)
    print(log_map)
    file_txt.write(log_map)
    file_txt.write('\n')


if __name__ == '__main__':

    args = parse_arguments(sys.argv[1:])
    category_list = args.category_list
    test_result_path = args.test_result_path
    test_image_path = args.test_image_path

    classes = []
    if ',' in category_list:
        classes = category_list.split(',')
    else:
        classes.append(category_list)

    ap_of_every_class(test_result_path, classes, test_image_path)
