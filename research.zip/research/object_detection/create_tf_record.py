from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import hashlib
import io
import os
import json
import numpy as np
from tqdm import tqdm

from lxml import etree
import PIL.Image
import tensorflow as tf

from object_detection.utils import dataset_util
from object_detection.utils import label_map_util

flags = tf.app.flags
flags.DEFINE_string('datasets_dir', '', 'Root directory to raw PASCAL VOC dataset.')
flags.DEFINE_string('output_path', '', 'Path to output TFRecord')
flags.DEFINE_string('flag', '', 'xml or json')
flags.DEFINE_string('label_map_path', 'data/pascal_label_map.pbtxt',
                    'Path to label map proto')
flags.DEFINE_float('valid_ratio', 0.1,
                   'proportion of training data,the default is 1,proportion of validation set is 1-train_ratio')
FLAGS = flags.FLAGS


def dict_to_tf_example(data, dataset_directory, label_map_dict, flag):
    xmin, ymin, xmax, ymax = [], [], [], []
    classes, classes_text, truncated, poses, difficult_obj = [], [], [], [], []
    full_path = ''
    width, height = 0, 0
    filename = ''.encode('utf8')
    if flag == 'xml':
        full_path = os.path.join(dataset_directory, data['filename'])
        width = int(data['size']['width'])
        height = int(data['size']['height'])
        filename = data['filename'].encode('utf8')
        if 'object' in data:
            for obj in data['object']:
                difficult = bool(int(obj['difficult']))
                # if ignore_difficult_instances and difficult:
                #     continue
                difficult_obj.append(int(difficult))
                xmin.append(float(obj['bndbox']['xmin']) / width)
                ymin.append(float(obj['bndbox']['ymin']) / height)
                xmax.append(float(obj['bndbox']['xmax']) / width)
                ymax.append(float(obj['bndbox']['ymax']) / height)
                classes_text.append(obj['name'].encode('utf8'))
                classes.append(label_map_dict[obj['name']])
                truncated.append(int(obj['truncated']))
                poses.append(obj['pose'].encode('utf8'))
    if flag == 'json':
        full_path = os.path.join(dataset_directory, data['imagePath'])
        filename = data['imagePath'].encode('utf8')
        width = int(data['imageHeight'])
        height = int(data['imageWidth'])
        for shape_list in data['shapes']:
            if shape_list['shape_type'] == 'rectangle':
                points = shape_list['points']
                if points[0][0] != points[1][0] and points[0][1] != points[1][1]:
                    xmin.append(float(min(points[0][0], points[1][0])) / width)
                    xmax.append(float(min(points[0][0], points[1][0])) / width)
                    ymin.append(float(min(points[0][1], points[1][1])) / height)
                    ymax.append(float(min(points[0][1], points[1][1])) / height)
                else:
                    raise ValueError('Mislabeling')
            # difficult = bool(0)
            # if ignore_difficult_instances and difficult:
            #     continue

            difficult_obj.append(0)
            classes_text.append(shape_list['label'].encode('utf8'))
            classes.append(label_map_dict[shape_list['label']])
            truncated.append(0)
            poses.append("Unspecified".encode('utf8'))
    with tf.gfile.GFile(full_path, 'rb') as fid:
        encoded_jpg = fid.read()
    encoded_jpg_io = io.BytesIO(encoded_jpg)
    image = PIL.Image.open(encoded_jpg_io)
    if image.format != 'JPEG':
        raise ValueError('Image format not JPEG')
    key = hashlib.sha256(encoded_jpg).hexdigest()

    example = tf.train.Example(features=tf.train.Features(feature={
        'image/height': dataset_util.int64_feature(height),
        'image/width': dataset_util.int64_feature(width),
        'image/filename': dataset_util.bytes_feature(
            filename),
        'image/source_id': dataset_util.bytes_feature(
            filename),
        'image/key/sha256': dataset_util.bytes_feature(key.encode('utf8')),
        'image/encoded': dataset_util.bytes_feature(encoded_jpg),
        'image/format': dataset_util.bytes_feature('jpeg'.encode('utf8')),
        'image/object/bbox/xmin': dataset_util.float_list_feature(xmin),
        'image/object/bbox/xmax': dataset_util.float_list_feature(xmax),
        'image/object/bbox/ymin': dataset_util.float_list_feature(ymin),
        'image/object/bbox/ymax': dataset_util.float_list_feature(ymax),
        'image/object/class/text': dataset_util.bytes_list_feature(classes_text),
        'image/object/class/label': dataset_util.int64_list_feature(classes),
        'image/object/difficult': dataset_util.int64_list_feature(difficult_obj),
        'image/object/truncated': dataset_util.int64_list_feature(truncated),
        'image/object/view': dataset_util.bytes_list_feature(poses),
    }))
    return example


def get_camera_info(json_list):
    camera_id_info = {}
    for file_path in json_list:
        file_name = os.path.basename(file_path)
        camera_id = str(file_name.split('_')[0])
        if len(file_name.split('_')) > 2:
            camera_id += '_' + str(file_name.split('_')[1])
        if camera_id not in camera_id_info.keys():
            camera_id_info[camera_id] = 0
        camera_id_info[camera_id] += 1
    return camera_id_info


def make_tfrecords(file_list, index_list, datasets_dir, gt_flag, label_map_dict, output_path):
    txt_name = str(os.path.basename(output_path).split('.')[0]) + '.txt'
    with open(os.path.join(os.path.dirname(output_path), txt_name), 'w') as file:
        writer = tf.python_io.TFRecordWriter(output_path)
        for idx in tqdm(index_list):
            file_name = file_list[idx]
            file.write(file_name)
            file.write('\n')
            gt_file = os.path.join(datasets_dir, file_name.split('.')[0] + '.' + gt_flag)
            data = {}
            if gt_flag == 'xml':
                with tf.gfile.GFile(gt_file, 'r') as fid:
                    xml_str = fid.read()
                xml = etree.fromstring(xml_str)
                data = dataset_util.recursive_parse_xml_to_dict(xml)['annotation']
            elif gt_flag == 'json':
                json_fp = open(gt_file, "r")
                data = json.load(json_fp)

            tf_example = dict_to_tf_example(data, datasets_dir, label_map_dict, gt_flag)
            writer.write(tf_example.SerializeToString())

        writer.close()


def allocate_train_valid(valid_ratio, camera_id_info, num_files):
    valid_index = []
    if valid_ratio:
        init_ind = 0
        for key, value in camera_id_info.items():
            if value <= 1:
                continue
            choice_size = int(value * valid_ratio)
            if choice_size < 1:
                choice_size = 1
            temp_valid_index = list(
                np.random.choice(range(init_ind, init_ind + value), size=choice_size, replace=False))
            init_ind += value
            valid_index.extend(temp_valid_index)
    train_index = [x for x in range(num_files) if x not in valid_index]
    return valid_index, train_index


def main(_):
    np.random.seed(1)
    flag = FLAGS.flag
    valid_ratio = FLAGS.valid_ratio
    datasets_dir = FLAGS.datasets_dir
    output_path = FLAGS.output_path
    os.makedirs(output_path, exist_ok=True)

    label_map_dict = label_map_util.get_label_map_dict(FLAGS.label_map_path)
    filenames = [x.strip('\n') for x in open(os.path.join(datasets_dir, 'trainval.txt'), 'r')]
    num_files = len(filenames)
    camera_id_info = get_camera_info(filenames)
    valid_index, train_index = allocate_train_valid(valid_ratio, camera_id_info, num_files)

    if train_index:
        print('Generate train tfreocrds...')
        make_tfrecords(filenames, train_index, datasets_dir, flag, label_map_dict,
                       os.path.join(output_path, 'train.tfrecords'))
    if valid_index:
        print('Generate valid tfreocrds...')
        make_tfrecords(filenames, valid_index, datasets_dir, flag, label_map_dict,
                       os.path.join(output_path, 'val.tfrecords'))
    print('Finished!')


if __name__ == '__main__':
    tf.app.run()
