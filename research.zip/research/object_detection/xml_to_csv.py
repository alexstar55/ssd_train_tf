import glob
import pandas as pd
import xml.etree.ElementTree as ET
import argparse
import sys
from object_detection.utils import label_map_util
from tqdm import tqdm

#TODO merge with generate tfrecord function
def parse_arguments(argv):
    parser = argparse.ArgumentParser()
    parser.add_argument('--gt_path', type=str, help='Directory where gt files are located.', default='')
    parser.add_argument('--csv_path', type=str, help='Path to save csv file.', default='')
    parser.add_argument('--pbtxt_path', type=str, help='Directory where pbtxt is located.', default='')
    return parser.parse_args(argv)


def xml_to_csv(path, category_list):
    xml_list = []
    for xml_file in tqdm(glob.glob(path + '/*.xml')):
        tree = ET.parse(xml_file)
        root = tree.getroot()
        for member in root.findall('object'):
            class_name = member[0].text
            if class_name in category_list:
                value = (root.find('filename').text,
                         int(root.find('size')[0].text),
                         int(root.find('size')[1].text),
                         member[0].text,
                         int(member[5][0].text),
                         int(member[5][1].text),
                         int(member[5][2].text),
                         int(member[5][3].text)
                         )
                xml_list.append(value)
    column_name = ['filename', 'width', 'height', 'class', 'xmin', 'ymin', 'xmax', 'ymax']
    xml_df = pd.DataFrame(xml_list, columns=column_name)
    return xml_df


def main(args):
    gt_path = args.gt_path
    csv_path = args.csv_path
    pbtxt_path = args.pbtxt_path

    category_dict = label_map_util.create_category_index_from_labelmap(pbtxt_path, use_display_name=True)
    category_list = []
    for value in category_dict.values():
        category_list.append(value['name'])
    xml_df = xml_to_csv(gt_path, category_list)
    xml_df.to_csv(csv_path, index=None)
    print('Successfully converted xml to csv.')


if __name__ == '__main__':
    main(args=parse_arguments(sys.argv[1:]))
